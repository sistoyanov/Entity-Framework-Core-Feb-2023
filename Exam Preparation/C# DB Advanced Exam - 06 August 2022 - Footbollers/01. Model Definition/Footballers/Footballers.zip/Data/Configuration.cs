﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Footballers;Trusted_Connection=True";
    }
}
