﻿using System.Xml.Serialization;

namespace VaporStore.Data.Models.Enums;


public enum PurchaseType
{
    //[XmlEnum("0")]
    Retail = 0,
    
    //[XmlEnum("1")]
    Digital = 1
}
