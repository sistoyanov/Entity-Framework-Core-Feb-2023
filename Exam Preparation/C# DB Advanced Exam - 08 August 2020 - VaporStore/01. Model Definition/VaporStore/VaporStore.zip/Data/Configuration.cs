﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=.;Database=VaporStore;Integrated Security=True;Encrypt=False";
    }
}