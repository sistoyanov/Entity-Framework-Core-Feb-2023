﻿using System.Xml.Serialization;

namespace SoftJail.Data.Models.Enums;

public enum Weapon
{
    //[XmlEnum("0")]
    Knife = 0,

    //[XmlEnum("1")]
    FlashPulse = 1,

    //[XmlEnum("2")]
    ChainRifle = 2,

    //[XmlEnum("3")]
    Pistol = 3,

    //[XmlEnum("4")]
    Sniper = 4
}
