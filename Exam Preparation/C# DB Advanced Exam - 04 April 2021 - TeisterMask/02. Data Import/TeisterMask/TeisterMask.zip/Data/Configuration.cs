﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=TeisterMask;Integrated Security=True;Encrypt=False";
    }
}
