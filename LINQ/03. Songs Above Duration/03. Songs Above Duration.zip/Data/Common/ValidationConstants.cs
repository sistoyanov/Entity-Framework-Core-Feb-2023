﻿namespace MusicHub.Data.Common;

public class ValidationConstants
{
    public const int SongNameMaxLenght = 20;

    public const int AlbumNameMaxLenght = 40;

    public const int PerformerFirstNameMaxLenght = 20;
    public const int PerformerLastNameMaxLenght = 20;

    public const int ProducerNameMaxLenght = 30;

    public const int WriterNameMaxLenght = 20;
}
