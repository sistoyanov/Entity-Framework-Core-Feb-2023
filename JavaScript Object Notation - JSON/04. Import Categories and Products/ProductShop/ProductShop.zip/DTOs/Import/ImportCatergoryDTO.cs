﻿namespace ProductShop.DTOs.Import;

public class ImportCatergoryDTO
{
    public string Name { get; set; } = null!;
}
